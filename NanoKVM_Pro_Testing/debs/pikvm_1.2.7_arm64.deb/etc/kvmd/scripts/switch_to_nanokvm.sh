#!/bin/bash

FILE="/etc/kvm/server.txt"
DIR=$(dirname "$FILE")

if [ ! -d "$DIR" ]; then
    echo "create: $DIR"
    sudo mkdir -p "$DIR"
fi

echo "nanokvm" | sudo tee "$FILE" > /dev/null

sync
reboot
