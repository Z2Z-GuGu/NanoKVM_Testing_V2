#!/bin/bash

SW_PWR_GPIO="/sys/class/gpio/gpio7/value"
SW_RST_GPIO="/sys/class/gpio/gpio35/value"
PWRLED_GPIO="/sys/class/gpio/gpio75/value"
HDDLED_GPIO="/sys/class/gpio/gpio74/value"

press_button() {
    local gpio=$1
    local duration=$2
    echo 1 | tee "$gpio"
    sleep "$duration"
    echo 0 | tee "$gpio"
}

read_led() {
    case "$1" in
        pwr)
            echo "PWRLED: $(cat $PWRLED_GPIO)"
            ;;
        hdd)
            echo "HDDLED: $(cat $HDDLED_GPIO)"
            ;;
        *)
            echo "Usage: $0 status {pwr|hdd}"
            exit 1
            ;;
    esac
}

case "$1" in
    short)
        echo "Short press (SW_PWR)"
        press_button "$SW_PWR_GPIO" 1
        ;;
    long)
        echo "Long press (SW_PWR)"
        press_button "$SW_PWR_GPIO" 5
        ;;
    reset)
        echo "Reset press (SW_RST)"
        press_button "$SW_RST_GPIO" 1
        ;;
    status)
        read_led "$2"
        ;;
    *)
        echo "Usage: $0 {short|long|reset|status {pwr|hdd}}"
        ;;
esac
