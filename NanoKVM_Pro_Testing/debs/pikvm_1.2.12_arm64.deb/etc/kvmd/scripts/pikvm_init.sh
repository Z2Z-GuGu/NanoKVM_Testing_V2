#!/bin/bash

chown root:root /
chown -R root:root /etc/sudoers.d
chmod 750 /etc/sudoers.d

ldconfig

systemd-sysusers /usr/lib/sysusers.d/kvmd.conf
systemd-sysusers /usr/lib/sysusers.d/kvmd-webterm.conf

if [[ -f /etc/kvm/server.key && -f /etc/kvm/server.crt ]]; then
    echo "-> Found existing SSL certificates, creating symlinks..." | tee -a $LOGFILE
    ln -sf /etc/kvm/server.key /etc/kvmd/nginx/ssl/server.key
    ln -sf /etc/kvm/server.crt /etc/kvmd/nginx/ssl/server.crt
else
    echo "-> SSL certificates not found, generating new ones..." | tee -a $LOGFILE
    kvmd-gencert --do-the-thing
fi

kvmd-gencert --do-the-thing --vnc

echo "-> Creating symlinks for use with kvmd python scripts" | tee -a $LOGFILE
if [ ! -e /usr/bin/nginx ]; then ln -sf /usr/sbin/nginx /usr/bin/; fi
if [ ! -e /usr/sbin/python ]; then ln -sf /usr/bin/python /usr/sbin/python; fi
if [ ! -e /usr/bin/iptables ]; then ln -sf /usr/sbin/iptables /usr/bin/iptables; fi
if [ ! -e /usr/share/tessdata ]; then ln -sf /usr/share/tesseract-ocr/*/tessdata /usr/share/tessdata; fi

mkdir -p /home/kvmd-webterm
echo "kvmd-webterm ALL=(ALL) NOPASSWD: ALL" > /etc/sudoers.d/kvmd-webterm; chmod 440 /etc/sudoers.d/kvmd-webterm

chown kvmd:kvmd /etc/kvmd/htpasswd
chown kvmd-ipmi:kvmd-ipmi /etc/kvmd/ipmipasswd
chown kvmd-vnc:kvmd-vnc /etc/kvmd/vncpasswd
chown kvmd-webterm /home/kvmd-webterm

usermod -a -G video kvmd
usermod -a -G dialout kvmd
usermod -a -G disk kvmd

chmod go+r /etc/kvmd/totp.secret
chown kvmd:kvmd /etc/kvmd/totp.secret
touch /usr/local/bin/rw /usr/local/bin/ro
chmod +x /usr/local/bin/rw /usr/local/bin/ro
sed -i -e "s/localhost.localdomain/`hostname`/g" /etc/kvmd/meta.yaml
systemd-tmpfiles --create /usr/lib/tmpfiles.d/kvmd.conf
udevadm control --reload
udevadm control --reload-rules
udevadm trigger
